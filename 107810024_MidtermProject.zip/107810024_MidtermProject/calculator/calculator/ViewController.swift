//
//  ViewController.swift
//  caculator
//
//  Created by patty on 2022/4/29.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    lazy var calculator = Calculator()
    @IBOutlet weak var OUTPUT: UILabel!
    @IBOutlet weak var process: UILabel!
    
    @IBOutlet weak var AC: UIButton!
    
    func updateViewFromModel() {
        if (calculator.firstNumber != 0 || calculator.mathOperator != "") {
            process.text = calculator.firstText
        }
        else {
            process.text = calculator.secondText
        }
        switch calculator.mathOperator {
        case "%":
            process.text = process.text! + calculator.mathOperator
        case "+":
            process.text = process.text! + calculator.mathOperator
        case "-":
            process.text = process.text! + calculator.mathOperator
        case "x":
            process.text = process.text! + calculator.mathOperator
        case "÷":
            process.text = process.text! + calculator.mathOperator
        default:
            break
        }
        if calculator.mathOperator != "" {
            process.text = process.text! + calculator.secondText
        }
    }
    
    @IBAction func Plus(_ sender: UIButton) {
        calculator.plus()
        OUTPUT.text = calculator.outputText
        changeColor()
        sender.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        sender.tintColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        currentOperatorBtn = sender
        typeOperation = true
        updateViewFromModel()
    }
    
    @IBAction func Minus(_ sender: UIButton) {
        calculator.minus()
        OUTPUT.text = calculator.outputText
        changeColor()
        sender.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        sender.tintColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        currentOperatorBtn = sender
        typeOperation = true
        updateViewFromModel()
    }
    
    @IBAction func Multiply(_ sender: UIButton) {
        calculator.multiply()
        OUTPUT.text = calculator.outputText
        changeColor()
        sender.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        sender.tintColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        currentOperatorBtn = sender
        typeOperation = true
        updateViewFromModel()
    }
        
    @IBAction func Divide(_ sender: UIButton) {
        calculator.divide()
        OUTPUT.text = calculator.outputText
        changeColor()
        sender.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        sender.tintColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        currentOperatorBtn = sender
        typeOperation = true
        updateViewFromModel()
    }
    
    @IBAction func Equal(_ sender: UIButton) {
        calculator.equal()
        process.text! += "="
        OUTPUT.text = calculator.outputText
        AC.setTitle("C",for: .normal)
        changeColor()
        typeOperation = false
    }
    
    @IBAction func number(_ sender: UIButton) {
        if (calculator.complete == true) {
            calculator.complete = false
            OUTPUT.text = ""
            OUTPUT.text = OUTPUT.text! + (sender.titleLabel?.text!)!
            calculator.secondNumber = Double(OUTPUT.text!)!
            calculator.firstNumber = 0
            calculator.mathOperator = ""
        }
        else {
            if (OUTPUT.text == "0" && sender.titleLabel?.text! != "0") {
                OUTPUT.text = ""
            }
            if (OUTPUT.text != "0" || sender.titleLabel?.text! != "0") {
                OUTPUT.text = OUTPUT.text! + (sender.titleLabel?.text!)!
                calculator.secondNumber = Double(OUTPUT.text!)!
                if (calculator.secondNumber - floor(calculator.secondNumber) != 0.0){
                    calculator.secondText = String(calculator.secondNumber)
                    calculator.secondText = String(calculator.secondNumber)
                }else{
                    calculator.secondText = String(Int(calculator.secondNumber))
                    calculator.secondText = String(Int(calculator.secondNumber))
                }
            }
        }
        AC.setTitle("C",for: .normal)
        changeColor()
        typeOperation = false
        updateViewFromModel()
    }
    
    @IBAction func C(_ sender: UIButton) {
        calculator.complete = false
        calculator.mathOperator = ""
        calculator.firstNumber = 0
        calculator.firstText = ""
        calculator.secondNumber = 0
        calculator.secondText = ""
        calculator.output = 0
        calculator.outputText = ""
        OUTPUT.text = "0"
        sender.setTitle("AC",for: .normal)
        changeColor()
        typeOperation = false
        updateViewFromModel()
    }
    
    @IBAction func Dot(_ sender: UIButton) {
        if (OUTPUT.text?.contains("."))!{
            OUTPUT.text! += ""
        }
        else{
            OUTPUT.text! += "."
        }
    }
    
    @IBAction func PositiveOrNegative(_ sender: UIButton) {
        calculator.PositiveAndNegative()
        OUTPUT.text = calculator.outputText
        updateViewFromModel()
    }
    
    @IBAction func Percentage(_ sender: UIButton) {
        calculator.percentage()
        OUTPUT.text = calculator.outputText
        updateViewFromModel()
    }
    
    var currentOperatorBtn:UIButton?
    var typeOperation = false
    func changeColor(){
        if currentOperatorBtn != nil {
            currentOperatorBtn?.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
            currentOperatorBtn?.tintColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            currentOperatorBtn = nil
        }
    }
    
}

