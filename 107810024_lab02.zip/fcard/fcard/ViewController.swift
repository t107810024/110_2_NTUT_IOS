//
//  ViewController.swift
//  fcard
//
//  Created by student on 2022/3/21.
//  Copyright © 2022年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //#colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
    
    @IBOutlet weak var flipLabel: UILabel!
    
    var fCount:Int = 0{
        didSet{
            flipLabel.text="Flips:\(fCount)"
        }
    }

    @IBOutlet weak var Button1: UIButton!
    
    @IBAction func Button1(_ sender: UIButton){
        if sender.currentTitle == "🤡"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("🤡", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    @IBOutlet weak var Button2: UIButton!
    
    @IBAction func Button2(_ sender: UIButton){
        if sender.currentTitle == "👿"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("👿", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    @IBOutlet weak var Button3: UIButton!
    
    @IBAction func Button3(_ sender: UIButton){
        if sender.currentTitle == "🤠"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("🤠", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    @IBOutlet weak var Button4: UIButton!
    
    @IBAction func Button4(_ sender: UIButton){
        if sender.currentTitle == "🤡"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("🤡", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    @IBOutlet weak var Button5: UIButton!
    
    @IBAction func Button5(_ sender: UIButton){
        if sender.currentTitle == "🐟"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("🐟", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    @IBOutlet weak var Button6: UIButton!
    
    @IBAction func Button6(_ sender: UIButton){
        if sender.currentTitle == "🤠"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("🤠", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    @IBOutlet weak var Button7: UIButton!
    
    @IBAction func Button7(_ sender: UIButton){
        if sender.currentTitle == "🐟"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("🐟", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    
    @IBOutlet weak var Button8: UIButton!
    
    @IBAction func Button8(_ sender: UIButton){
        if sender.currentTitle == "👿"{
            sender.setTitle("", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        }else{
            sender.setTitle("👿", for: .normal)
            sender.backgroundColor = #colorLiteral(red: 0.9183036685, green: 0.9094227552, blue: 0.8272650838, alpha: 1)
        }
        fCount+=1
        flipLabel.text="Flips:\(fCount)"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = #colorLiteral(red: 0.6432855725, green: 0.753300488, blue: 0.6852383614, alpha: 1)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}


