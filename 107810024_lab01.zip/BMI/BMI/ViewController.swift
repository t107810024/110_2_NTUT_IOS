//
//  ViewController.swift
//  BMI
//
//  Created by student on 2022/3/14.
//  Copyright © 2022年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var height: UITextField!
    @IBOutlet weak var weight: UITextField!
    @IBOutlet weak var bmi: UILabel!
    @IBOutlet var type: UILabel!
    @IBOutlet weak var sex: UISegmentedControl!
    var sexChoice = 0
    
    @IBAction func sexe(_ sender: UISegmentedControl) {
        if sex.selectedSegmentIndex == 0 {
            sexChoice = 0
        } else if sender.selectedSegmentIndex == 1 {
            sexChoice = 1
        }
    }
    
    @IBAction func calculator(_sender: Any) {
        let h = Float(height.text!)!/100.0
        let w = Float(weight.text!)!
        let b = w/(h*h)
        
        bmi.text! = "Your BMI: \(String(b))"
        
        if(b < 18.5) {
            type.text = "Weight status: Underweight"
        }else if(b >= 18.5 && b<24.9){
            type.text = "Weight status: Healthy weight"
        }else if(b >= 25.0 && b<29.9){
            if(sexChoice == 0) {
                type.text = "Weight status: Overweight"
            }else {
                type.text = "Weight status: It's a secert"
            }
        }else {
            if(sexChoice == 0){
                type.text = "Weight status: Obesity"
            }else {
                type.text = "Weight status: It's a secert"
            }
        }
    }
}

